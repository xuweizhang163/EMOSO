function Offspring = Operator(Population,Rank)
% The  EMOSO

%------------------------------- Copyright --------------------------------
% Copyright (c) 2018-2019 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    %% Parameter setting
    P_Dec  = Population.decs;
    Global    = GLOBAL.GetObj();
    [N,D]     = size(P_Dec);
    V      = Population.adds(zeros(N,D));
    OffDec=P_Dec;
    OffVel=zeros(N,D);
    NL=4;
    LS=floor(N/NL);
    LSN=N-LS*(NL-1);
    vc=1:NL;
    c1=rand(1,D);
    c2=rand(1,D);
    P_Obj  = Population.objs;
    Front     = NDSort(P_Obj,inf);
    [~,rank]  = sortrows([Front',-CrowdingDistance(P_Obj,Front)']);
    LeaderSet = rank(1:5);
    MP=mean(P_Dec);
    %%%%
    for w=1:NL-1
        if w==1
            LSK(w,1:LS)=Rank(1:LS);
        else
            LSK(w,1:LS)=Rank((w-1)*LS+1:w*LS);
        end
    end
    %%
    for i=1:NL            
        if i==NL
            gh=Rank(N-LSN+1:end);
            rl=randperm(NL-1,2);
            rl1=rl(1);
            rl2=rl(2);
            l=randi(LS,1,2);
            lk1=LSK(rl1,l(1));
            lk2=LSK(rl2,l(2));
            for j=1:LSN
                win=LeaderSet(randi(5,1));
                E=(c1.*P_Dec(lk1,:)+c2.*(P_Dec(lk2,:)))./(c1+c2);
                OffVel(gh(j),:)=unifrnd(0,1,1,D).*V(gh(j),:)+rand(1,D).*(E-MP)+rand(1,D).*(P_Dec(win,:)-P_Dec(gh(j),:));%
                OffDec(gh(j),:)=P_Dec(gh(j),:)+OffVel(gh(j),:);
            end
        elseif i==1
            for j=1:LS
                 win=LeaderSet(randi(5,1));
                OffVel(LSK(1,j),:)=unifrnd(0,1,1,D).*V(LSK(1,j),:)+rand(1,D).*(MP-P_Dec(LSK(1,j),:))+rand(1,D).*(P_Dec(win,:)-P_Dec(LSK(1,j),:));
                OffDec(LSK(1,j),:)=P_Dec(LSK(1,j),:)+OffVel(LSK(1,j),:);
            end
        else
            for j=1:LS
                if i==2
                    lk=randi(LS,1,2);
                    lk1=LSK(1,lk(1));
                    lk2=LSK(1,lk(2));
                else
                    rl=randperm(i-1,2);
                    rl1=rl(1);
                    rl2=rl(2);
                    l=randi(LS,1,2);
                    lk1=LSK(rl1,l(1));
                    lk2=LSK(rl2,l(2));
                end
                %%%
                win=LeaderSet(randi(5,1));
                E=(c1.*P_Dec(lk1,:)+c2.*(P_Dec(lk2,:)))./(c1+c2);
                OffVel(LSK(i,j),:)=unifrnd(0,1,1,D).*V(LSK(i,j),:)+rand(1,D).*(E-MP)+rand(1,D).*(P_Dec(win,:)-P_Dec(LSK(i,j),:));
                OffDec(LSK(i,j),:)=P_Dec(LSK(i,j),:)+OffVel(LSK(i,j),:);
            end
        end
    end
    %% Polynomial mutation
    Lower  = repmat(Global.lower,N,1);
    Upper  = repmat(Global.upper,N,1);
    disM   = 20;
    Site   = rand(N,D) < 1/D;
    mu     = rand(N,D);
    temp   = Site & mu<=0.5;
    OffDec       = max(min(OffDec,Upper),Lower);
    OffDec(temp) = OffDec(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
                   (1-(OffDec(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);
    temp  = Site & mu>0.5; 
    OffDec(temp) = OffDec(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
                   (1-(Upper(temp)-OffDec(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));
	Offspring = INDIVIDUAL(OffDec,OffVel);
end